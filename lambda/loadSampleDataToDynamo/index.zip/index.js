let AWS = require('aws-sdk')

let s3 = new AWS.S3();
let dynamodb = new AWS.DynamoDB();

module.exports.handler = async event => {

  var s3Params = {
    Bucket: event.BucketName,
    Key: event.FileName
  };

  s3.getObject(s3Params, function(err, data) {
    if(err) {
      return {
        statusCode: 500,
        body: JSON.stringify(
          {
            message: `Unable to get object from ${event.BucketName} with file name ${event.FileName}`,
            input: event,
            errorMessage: err.stack,
            error: err
          },
          null,
          2
        ),
      };
    } else {
      var dataLoadSuccess = executeDynamoLoad(data, event);
      if(!dataLoadSuccess) {
        return {
          statusCode: 500,
          body: JSON.stringify(
            {
              message: `Error loading data into ${event.TableName}`,
              input: event
            },
            null,
            2
          ),
        };
      } else {
        return {
          statusCode: 200,
          body: JSON.stringify(
            {
              message: "Successfully loaded sample data!",
              input: event
            },
            null,
            2
          ),
        };
      }
    }
  });
}

function executeDynamoLoad(data, event) {
  var fieldsList = data.fields;
  data.data.forEach(neo => {
    var neoObject = {
      "des": neo[0],
      "orbit_id": neo[1],
      "jd": neo[2],
      "cd": neo[3],
      "dist": neo[4],
      "dist_min": neo[5],
      "dist_max": neo[6],
      "v_rel": neo[7],
      "v_inf": neo[8],
      "t_sigma_f": neo[9],
      "body": neo[10],
      "h": neo[11]  
    };

    var params = {
      Item: {
        "designation": {
          S: neoObject.des
        },
        "absolute_magnitude": {
          N: neoObject.h
        },
        "orbit_id": {
          N: neoObject.orbit_id
        },
        "time_of_close_approach": {
          S: neoObject.jd
        },
        "time_of_close_approach_calendar": {
          S: neoObject.cd
        },
        "approach_distance": {
          N: neoObject.dist
        },
        "approach_distance_min": {
          N: neoObject.dist_min
        },
        "approach_distance_max": {
          N: neoObject.dist_max
        },
        "relative_velocity": {
          N: neoObject.v_rel
        },
        "velocity": {
          N: neoObject.v_inf
        },
        "body": {
          S: neoObject.body
        },
        "close_time_approach_uncertainty": {
          S: neoObject.t_sigma_f
        }
      },
      TableName: event.TableName
    }

    dynamodb.putItem(params, function(err, data) {
      if(err) {
        console.log(`Unable to load NEO with designation ${neoObject.des} into ${event.TableName}. Full error is ${err} with stack ${err.stack}`)
        return false;
      } else {
        console.log(`Successfully loaded NEO with designation ${neoObject.des}`);
      }
    });
  });
}